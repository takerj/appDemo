/**
 * @description 防抖函数
 * @param {Func} fn 方法名称
 * @param {number} wait 等待时间
 */
type Func = (...args: any[]) => any;
export function debounce(fn: Func, wait: number): Func {
  let timeout: any;
  return function (this: any, ...args: any[]) {
    clearTimeout(timeout);
    timeout = setTimeout(() => {
      fn.apply(this, args);
    }, wait);
  };
}
