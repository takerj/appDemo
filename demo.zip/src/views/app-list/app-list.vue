<template>
  <div class="free-list-wrapper">
    <van-list :finished="finished" :immediate-check="false" @load="onLoad">
      <div class="free-item" v-for="(item, index) in listData" :key="item.id">
        <span class="number">{{ index + 1 }}</span>
        <div class="img-content-wrapper">
          <img :src="item.imgSrc" alt="" class="item-icon" />
          <div class="content-wrapper">
            <div class="title">{{ item.title }}</div>
            <div class="label">{{ item.label }}</div>
            <div class="star-wrapper">
              <van-rate
                readonly
                v-model="item.averageUserRating"
                allow-half
                class="rate-wrapper"
                size="12"
                color="#f9d34e"
              />
              <span class="count">({{ item.userRatingCount }})</span>
            </div>
          </div>
        </div>
      </div>
    </van-list>
  </div>
</template>
<script setup lang="ts">
import { computed, ref, watch } from 'vue';

const props = defineProps<{
  list: AppItem[];
}>();
// 加载数据
const loading = ref(false);
const finished = ref(false);

const pageIndex = ref(1);
const pageSize = 10;

watch(
  () => props.list.length,
  () => {
    finished.value = false;
    pageIndex.value = 1;
  }
);

const listData = computed(() => {
  return props.list.slice(0, pageIndex.value * pageSize);
});

const onLoad = () => {
  if (loading.value) return;
  setTimeout(() => {
    pageIndex.value++;
    loading.value = false;
    if (pageIndex.value * pageSize >= props.list.length) {
      finished.value = true;
    }
  }, 500);
};
</script>
<style lang="less">
.free-list-wrapper {
  padding-left: 24px;
  .free-item {
    padding: 16px 0;
    display: flex;
    align-items: center;
    border-bottom: 1px solid #ededed;
    padding-right: 24px;
    .img-content-wrapper {
      display: flex;
      align-items: stretch;
    }
    &:nth-child(2n) {
      .item-icon {
        border-radius: 50%;
      }
    }
    .count {
      margin: 0 0 0 4px;
    }
    .item-icon {
      width: 100px;
      height: 100px;
      border-radius: 16px;
      margin: 0 24px;
    }
    .title {
      color: #121212;
      font-size: 24px;
    }
    .label {
      margin: 4px 0 8px;
    }
  }
}
</style>
