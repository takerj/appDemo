<template>
  <!-- 推荐模块 -->
  <div class="recommend-wrapper">
    <div class="title">Recommend</div>
    <div class="recommend-list">
      <div class="recommend-item" v-for="item in recommendList" :key="item.id">
        <img :src="item.imgSrc" alt="" class="avatar" />
        <div class="title">{{ item.title }}</div>
        <div class="desc">{{ item.label }}</div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue';
const recommendList = ref<AppItem[]>([]);
  import { FetchRecommendList} from '@/api/services/index';
//推荐模块
async function getData() {
  const res = await FetchRecommendList();
  recommendList.value = res.feed.entry.map(item => {
    const { category, title, id } = item;
    return {
      title: title.label,
      label: category.attributes.label,
      id: id.attributes['im:id'],
      imgSrc: item['im:image'][2].label || ''
    };
  });
}
onMounted(() => {
  getData();
});
</script>
<style lang="less">
.recommend-wrapper {
  padding: 0 0 16px 32px;
  border-bottom: 1px solid #ededed;
  .title {
    font-size: 32px;
    font-weight: 700;
    margin: 24px 0;
    color: #070707;
  }
  .recommend-list {
    overflow-x: auto;
    display: flex;
    .recommend-item {
      display: flex;
      flex-direction: column;
      align-items: center;
      margin: 0 40px 0 0;
      .avatar {
        width: 150px;
        height: 150px;
        border-radius: 10px;
      }
      .title {
        color: #121212;
        font-size: 26px;
        margin: 10px 0 6px;
        white-space: nowrap; /* 确保文本在一行内显示 */
        overflow: hidden; /* 超出容器的文本隐藏 */
        text-overflow: ellipsis; /* 超出部分显示省略号 */
        width: 150px; /* 定义容器宽度 */
      }
      .desc {
        color: #989898;
      }
    }
  }
}
</style>
