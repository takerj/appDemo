<template>
  <main class="applist-wrapper">
    <div class="search-wrapper">
      <van-field
        v-model="searchValue"
        left-icon="search"
        placeholder="search"
        class="search-input"
        @input="handleInput"
      />
    </div>
    <!-- 推荐列表 -->
    <RecommendList></RecommendList>
    <!-- 免费下载列表 -->
    <AppList :list="list"></AppList>
  </main>
</template>
<script setup lang="ts">
import RecommendList from './app-list/recommend-list.vue';
import AppList from './app-list/app-list.vue';
import { debounce } from '@/utils/index';
import { ref, onMounted } from 'vue';
import { FetchFreeList, FetchRatingInfoByIds } from '@/api/services/index';
onMounted(() => {
  getListData();
});
//免费下载列表
const list = ref<AppItem[]>([]);
let freelistRaw: AppItem[] = []; // 原始数据
async function getListData() {
  const listMap = new Map<string, AppItem>();
  const res = await FetchFreeList();
  let ids: string[] = [];
  // 提取所需要的字段
  res.feed.entry.forEach(item => {
    const { category, title, id, summary } = item;
    const idLabel = id.attributes['im:id'];
    ids.push(idLabel);
    listMap.set(idLabel, {
      title: title.label,
      label: category.attributes.label,
      id: idLabel,
      imgSrc: item['im:image'][0].label,
      searhText: `${item['im:name'].label}${item['im:artist'].label}${summary.label}}`
    });
  });

  // 根据id拿到相应数据的应用评人数和应用评级
  const { results } = await FetchRatingInfoByIds(ids.join(','));
  results.forEach(item => {
    const listItem = listMap.get(item.trackId + '');
    if (listItem) {
      const { userRatingCount, averageUserRating } = item;
      Object.assign(listItem, { userRatingCount, averageUserRating });
    }
  });
  list.value = [...listMap.values()];
  freelistRaw = list.value;
}
// 搜索处理
const searchValue = ref('');
const handleInput = debounce(() => {
  // 在这里执行实际的操作
  list.value = [];
  list.value = freelistRaw.reduce((prev: AppItem[], cur) => {
    if (cur.searhText?.includes(searchValue.value)) {
      prev.push(cur);
    }
    return prev;
  }, []);
}, 300);
</script>
<style scoped lang="less">
.applist-wrapper {
  overflow: hidden;
  font-size: 22px;
  color: #989898;
}
.search-wrapper {
  margin: 32px 0 0;
  border-bottom: 1px solid #ededed;
  padding: 0 24px 16px;
  .search-input {
    background: #f4f4f4;
    border-radius: 32px;
    width: 100%;
    margin: 0 auto;
    color: #9da8b1;
  }
}
</style>
