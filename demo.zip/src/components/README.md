组件标签应使用单词大写开头 (PascalCase)

并且使用多字符，不然会触发 vue/multi-word-component-names 检测
