<template>
  <RouterView />
</template>

<script setup lang="ts">
import { RouterView } from 'vue-router';
import { setToastDefaultOptions } from 'vant';

import 'vant/es/toast/style';
setToastDefaultOptions({ forbidClick: true });
setToastDefaultOptions('loading', { duration: 0 });
</script>
<style lang="less">
@import url('@/assets/css/common.less');
#app {
  width: 100%;
  height: 100%;
}
</style>
