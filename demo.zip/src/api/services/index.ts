// 如果有多个模块应按照模块拆分（url和请求方法）模块，再整体导出
import { request } from '@/api/axios/request';
// 获取免费列表数据
export function FetchFreeList(limit: number = 100) {
  return request<AppRequestData>(`/hk/rss/topfreeapplications/limit=${limit}/json`);
}
// 根据id获取应用评级和评论人数
export function FetchRatingInfoByIds(ids: string) {
  return request<RatingResult>(`hk/lookup?id=${ids}`);
}
// 获取推荐数据
export function FetchRecommendList(limit: number = 10) {
  return request<AppRequestData>(`/hk/rss/topgrossingapplications/limit=${limit}/json`);
}
