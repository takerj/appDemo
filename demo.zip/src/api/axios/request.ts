import type { AxiosRequestConfig } from 'axios';
import service from './axios';

/**
 * 接口请求
 * @param config 接口配置信息
 */
/** 常规请求 */
export async function request<T = boolean>(url: string, data: any = {}, config?: AxiosRequestConfig) {
  return service.request<T, T>({
    url,
    data,
    ...config
  });
}
