import axios from 'axios';

const service = axios.create({
  baseURL: '/api', // 视业务而定
  timeout: 10 * 1000, // 请求超时时间10s
  headers: {
    'Content-Type': 'application/json'
  }
});

service.interceptors.response.use(
  response => {
    return Promise.resolve(response.data);
  },
  error => {
    return Promise.reject(error);
  }
);

export default service;
