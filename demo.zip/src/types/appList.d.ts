interface AppItem {
  title: string;
  label: string;
  imgSrc: string;
  id: string;
  searhText?: string;
  userRatingCount?: number;
  averageUserRating?: number;
}
interface EntryItem {
  category: {
    attributes: {
      label: string;
    };
  };
  title: { label: string };
  'im:image': { label: string }[];
  id: {
    attributes: {
      'im:id': string;
    };
  };

  summary: {
    label: string;
  };
  'im:name': {
    label: string;
  };
  'im:artist': {
    label: string;
  };
}
interface AppRequestData {
  feed: {
    entry: EntryItem[];
  };
}
interface RatingResult {
  results: {
    averageUserRating: number;
    userRatingCount: number;
    trackId: number;
  }[];
}
