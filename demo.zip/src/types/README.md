```
TS类型定义文件夹

│   ├── types
│   │   ├── services           接口服务ts入参返参等等
│   │   ├── modules
│   │   ├── xxx.d.ts           公共ts类型定义
```
