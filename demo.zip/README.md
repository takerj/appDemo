# vue3-demo

### 介绍 📖

vue3-demo是基于 Vue3、TypeScript、Vite、vant 来实现appStore应用列表的

### 开始

```
npm run serve
```

### 打包构建

```
npm run build
```
